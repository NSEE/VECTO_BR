var class_vecto_input_manager_1_1_commands_1_1_service_collection_extensions =
[
    [ "ConfigureServices", "class_vecto_input_manager_1_1_commands_1_1_service_collection_extensions.html#af00d13932081cb5b337db89c50268793", null ]
];